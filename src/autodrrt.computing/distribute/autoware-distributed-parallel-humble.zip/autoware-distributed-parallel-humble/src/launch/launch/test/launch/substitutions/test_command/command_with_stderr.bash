#!/bin/bash

echo 'asd bsd' 1>&2
