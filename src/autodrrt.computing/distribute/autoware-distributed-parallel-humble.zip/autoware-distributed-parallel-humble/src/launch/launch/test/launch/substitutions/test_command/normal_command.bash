#!/bin/bash

echo 'asd bsd csd'
