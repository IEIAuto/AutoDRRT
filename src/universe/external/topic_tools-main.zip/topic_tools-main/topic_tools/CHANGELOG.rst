^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package topic_tools
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2022-02-22)
------------------
* Improve QoS detection robustness (`#27 <https://github.com/wep21/topic_tools/issues/27>`_)
  * improve qos detection robustness
  Co-authored-by: Emerson Knapp <eknapp@amazon.com>
* Feature/mux (`#26 <https://github.com/wep21/topic_tools/issues/26>`_)
  * feat: add mux
* Feature/transform (`#17 <https://github.com/wep21/topic_tools/issues/17>`_)
  * Add transform
* Contributors: Daisuke Nishimatsu, Steve Nogar
