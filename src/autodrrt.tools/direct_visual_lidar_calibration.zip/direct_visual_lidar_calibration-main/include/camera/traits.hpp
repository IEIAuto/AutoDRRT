#pragma once

namespace camera {

template <typename T>
struct CameraModelTraits;

}