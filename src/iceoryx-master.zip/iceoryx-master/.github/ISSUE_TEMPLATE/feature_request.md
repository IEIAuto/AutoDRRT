---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

## Brief feature description

Please describe in a few sentences what should be implemented

## Detailed information

E.g. a list of pros and cons of different considerations and how iceoryx and its user could benefit from it
