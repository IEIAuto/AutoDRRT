# iceoryx v2.0.1

## [v2.0.1](https://github.com/eclipse-iceoryx/iceoryx/tree/v2.0.1) (2022-04-01)

[Full Changelog](https://github.com/eclipse-iceoryx/iceoryx/compare/v2.0.0...v2.0.1)

**Bugfixes:**

- CMake warning: empty command-line option [\#1311](https://github.com/eclipse-iceoryx/iceoryx/issues/1311) thanks to @clalancette
- iox-#743 Fixes to make docs exportable [\#1289](https://github.com/eclipse-iceoryx/iceoryx/pull/1289)
- Don't exclude implementations of public classes in Doxygen [\#1293](https://github.com/eclipse-iceoryx/iceoryx/issues/1293)
