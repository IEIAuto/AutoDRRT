---
title: Implementing event triggered callbacks using C
---

{! ../iceoryx/iceoryx_examples/callbacks_in_c/README.md !}
