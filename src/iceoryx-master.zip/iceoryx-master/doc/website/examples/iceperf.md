---
title: Measuring the latency of different IPC mechanisms
---

{! ../iceoryx/iceoryx_examples/iceperf/README.md !}
