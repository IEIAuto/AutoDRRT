---
title: Minimize memory usage of roudi
---

{! ../iceoryx/iceoryx_examples/small_memory/README.md !}

