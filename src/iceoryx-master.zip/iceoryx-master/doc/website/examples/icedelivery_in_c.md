---
title: Sending and receiving data using C
---

{! ../iceoryx/iceoryx_examples/icedelivery_in_c/README.md !}
