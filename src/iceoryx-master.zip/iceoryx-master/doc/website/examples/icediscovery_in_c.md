---
title: Searching for currently available services using C
---

{! ../iceoryx/iceoryx_examples/icediscovery_in_c/README.md !}
